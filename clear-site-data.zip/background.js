// This background script is kept minimal
// It can be used for future extension functionality
console.log("Clear Site Data extension loaded");
